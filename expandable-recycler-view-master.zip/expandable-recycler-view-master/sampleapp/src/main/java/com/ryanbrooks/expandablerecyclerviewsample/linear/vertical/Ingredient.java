package com.ryanbrooks.expandablerecyclerviewsample.linear.vertical;

public class Ingredient {

    private String mName;

    public Ingredient(String name) {
        mName = name;
    }

    public String getName() {
        return mName;
    }
}
